#!/bin/bash
rsync -avz /eos/atlas/atlascerngroupdisk/proj-anubis/proANUBIS/data/ revering@pcna.hep.phy.cam.ac.uk:/r04/atlas/revering/data/

